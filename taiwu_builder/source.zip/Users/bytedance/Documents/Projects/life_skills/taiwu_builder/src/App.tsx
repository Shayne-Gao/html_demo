import BuilderPageV2 from "@/v2/BuilderPageV2";

export default function App() {
  return <BuilderPageV2 />;
}
