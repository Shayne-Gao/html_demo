import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { BuildRecord, BuildSectionKey, PracticeMode } from "@/types";
import { createEmptyBuild, defaultBuilds } from "@/utils/taiwuData";

type TaiwuState = {
  builds: BuildRecord[];
  selectedBuildId: string;
  selectBuild: (buildId: string) => void;
  createBuild: () => void;
  renameBuild: (buildId: string, name: string) => void;
  setBuildSkill: (params: {
    buildId: string;
    section: BuildSectionKey;
    slotId: string;
    skillId: string;
  }) => void;
  clearBuildSkill: (params: {
    buildId: string;
    section: BuildSectionKey;
    slotId: string;
  }) => void;
  setPracticeMode: (params: {
    buildId: string;
    section: BuildSectionKey;
    slotId: string;
    mode: PracticeMode;
  }) => void;
};

function updateBuild(builds: BuildRecord[], buildId: string, updater: (build: BuildRecord) => BuildRecord) {
  return builds.map((build) => (build.id === buildId ? updater(build) : build));
}

export const useTaiwuStore = create<TaiwuState>()(
  persist(
    (set) => ({
      builds: defaultBuilds,
      selectedBuildId: defaultBuilds[0].id,
      selectBuild: (buildId) => set({ selectedBuildId: buildId }),
      createBuild: () =>
        set((state) => {
          const build = createEmptyBuild();
          return {
            builds: [...state.builds, build],
            selectedBuildId: build.id,
          };
        }),
      renameBuild: (buildId, name) =>
        set((state) => ({
          builds: updateBuild(state.builds, buildId, (build) => ({
            ...build,
            name: name.trim() || build.name,
          })),
        })),
      setBuildSkill: ({ buildId, section, slotId, skillId }) =>
        set((state) => ({
          builds: updateBuild(state.builds, buildId, (build) => ({
            ...build,
            sections: {
              ...build.sections,
              [section]: build.sections[section].map((slot) =>
                slot.slotId === slotId ? { ...slot, skillId } : slot,
              ),
            },
          })),
        })),
      clearBuildSkill: ({ buildId, section, slotId }) =>
        set((state) => ({
          builds: updateBuild(state.builds, buildId, (build) => ({
            ...build,
            sections: {
              ...build.sections,
              [section]: build.sections[section].map((slot) =>
                slot.slotId === slotId ? { ...slot, skillId: null } : slot,
              ),
            },
          })),
        })),
      setPracticeMode: ({ buildId, section, slotId, mode }) =>
        set((state) => ({
          builds: updateBuild(state.builds, buildId, (build) => ({
            ...build,
            sections: {
              ...build.sections,
              [section]: build.sections[section].map((slot) =>
                slot.slotId === slotId ? { ...slot, practiceMode: mode } : slot,
              ),
            },
          })),
        })),
    }),
    {
      name: "taiwu-build-store",
      partialize: (state) => ({
        builds: state.builds,
        selectedBuildId: state.selectedBuildId,
      }),
    },
  ),
);
