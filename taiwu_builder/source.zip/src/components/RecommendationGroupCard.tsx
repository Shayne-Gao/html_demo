import SkillBadge from "@/components/SkillBadge";
import { getSkillById } from "@/utils/taiwuData";
import type { RecommendationGroup } from "@/types";

type RecommendationGroupCardProps = {
  group: RecommendationGroup;
};

export default function RecommendationGroupCard({ group }: RecommendationGroupCardProps) {
  return (
    <article className="rounded-[26px] border border-amber-200/10 bg-[#130d0a]/85 p-5 shadow-[0_18px_50px_rgba(0,0,0,0.35)]">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-full border border-amber-300/20 bg-amber-200/10 px-3 py-1 text-xs tracking-[0.14em] text-amber-100">
          {group.martial_category}
        </span>
        <span className="rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs tracking-[0.14em] text-cyan-100">
          {group.recommendation_category}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {group.skill_ids.map((skillId) => {
          const skill = getSkillById(skillId);
          return skill ? <SkillBadge key={skillId} skill={skill} /> : null;
        })}
      </div>

      <div className="mt-4 rounded-[20px] border border-stone-800 bg-stone-950/70 p-4 text-sm leading-7 text-stone-300/85">
        {group.recommendation_reason}
      </div>
    </article>
  );
}
