import type { CSSProperties, ReactNode } from "react";
import type { PracticeMode, SkillRecord } from "@/types";
import { getPracticeEffect, getSkillDisplayTags } from "@/utils/taiwuData";

type SkillTooltipProps = {
  skill: SkillRecord;
  practiceMode?: PracticeMode;
  style?: CSSProperties;
  className?: string;
  interactive?: boolean;
  footer?: ReactNode;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
};

export default function SkillTooltip({
  skill,
  practiceMode = "正练",
  style,
  className = "",
  interactive = false,
  footer,
  onMouseEnter,
  onMouseLeave,
}: SkillTooltipProps) {
  const currentEffect = getPracticeEffect(skill, practiceMode);
  const reverseEffect = getPracticeEffect(skill, practiceMode === "正练" ? "逆练" : "正练");
  const extraParagraphs = skill.paragraphs.filter((paragraph) => {
    const text = paragraph.trim();
    if (!text) return false;
    if (/^id:\d+/i.test(text)) return false;
    if (/^id:\d+\s*/i.test(text)) return false;
    if (text === "心法正练" || text === "心法逆练") return false;
    if (text.includes(skill.faction) && text.includes(skill.grade ?? "") && text.includes(skill.route) && text.includes(skill.category)) {
      return false;
    }
    return true;
  });

  return (
    <div
      className={`z-50 w-[min(380px,calc(100vw-2rem))] overflow-y-auto overscroll-contain rounded-[20px] border border-amber-900/12 bg-[#f9f1e6] p-4 text-stone-800 shadow-[0_24px_60px_rgba(78,52,22,0.18)] ${interactive ? "pointer-events-auto" : "pointer-events-none"} ${className}`}
      style={{ maxHeight: "min(70vh, 460px)", ...style }}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <p className="font-serif text-lg tracking-[0.08em] text-stone-900">{skill.name}</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {getSkillDisplayTags(skill).map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-amber-800/12 bg-white/80 px-2 py-1 text-[11px] tracking-[0.08em] text-stone-700"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="rounded-full border border-amber-800/15 bg-amber-100/55 px-2 py-1 text-[11px] tracking-[0.12em] text-amber-900">
          {practiceMode}
        </div>
      </div>

      <div className="space-y-3 text-sm leading-6">
        {currentEffect && (
          <div className="rounded-2xl border border-cyan-800/12 bg-cyan-50/90 p-3">
            <p className="text-xs tracking-[0.16em] text-cyan-800">{currentEffect.title}</p>
            <p className="mt-1 text-stone-800">{currentEffect.effect}</p>
          </div>
        )}

        {reverseEffect && (
          <div className="rounded-2xl border border-rose-800/12 bg-rose-50/88 p-3">
            <p className="text-xs tracking-[0.16em] text-rose-700">{reverseEffect.title}</p>
            <p className="mt-1 text-stone-700">{reverseEffect.effect}</p>
          </div>
        )}

        {extraParagraphs.slice(0, 1).map((paragraph) => (
          <p key={paragraph} className="text-stone-700">
            {paragraph}
          </p>
        ))}

        {footer ? (
          <div className="rounded-2xl border border-amber-900/10 bg-white/85 p-3">
            {footer}
          </div>
        ) : null}
      </div>
    </div>
  );
}
