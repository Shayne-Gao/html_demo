import { Plus, ScrollText } from "lucide-react";
import type { BuildRecord } from "@/types";

type BuildSidebarProps = {
  builds: BuildRecord[];
  selectedBuildId: string;
  onSelect: (buildId: string) => void;
  onCreate: () => void;
  onRename: (buildId: string, name: string) => void;
};

export default function BuildSidebar({
  builds,
  selectedBuildId,
  onSelect,
  onCreate,
  onRename,
}: BuildSidebarProps) {
  return (
    <aside className="flex h-full w-full flex-col rounded-[24px] border border-amber-800/12 bg-[#f8f1e8]/94 p-3 shadow-[0_16px_38px_rgba(94,60,25,0.08)]">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <p className="text-xs tracking-[0.22em] text-stone-500">BUILD 册</p>
          <p className="mt-1 font-serif text-lg text-stone-800">功法编排</p>
        </div>
        <button
          type="button"
          onClick={onCreate}
          className="rounded-full border border-amber-800/15 bg-white/55 p-2 text-amber-800 transition hover:border-amber-700/25 hover:bg-white/80"
        >
          <Plus size={18} />
        </button>
      </div>

      <div className="space-y-2 overflow-y-auto pr-1">
        {builds.map((build) => {
          const active = build.id === selectedBuildId;
          return (
            <div
              key={build.id}
              className={`w-full rounded-[14px] border p-2.5 text-left transition ${
                active
                  ? "border-amber-700/18 bg-[linear-gradient(145deg,rgba(229,207,179,0.95),rgba(246,238,226,0.96))]"
                  : "border-amber-900/8 bg-white/65 hover:border-amber-700/12 hover:bg-white/78"
              }`}
            >
              <button type="button" className="w-full text-left" onClick={() => onSelect(build.id)}>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-serif text-[15px] text-stone-800">{build.name}</p>
                    <p className="mt-0.5 text-[11px] tracking-[0.12em] text-stone-500">{build.theme}</p>
                  </div>
                  <ScrollText size={16} className={active ? "text-amber-800" : "text-stone-500"} />
                </div>
              </button>
              {active ? (
                <input
                  value={build.name}
                  onChange={(event) => onRename(build.id, event.target.value)}
                  className="mt-2 w-full rounded-lg border border-amber-900/10 bg-white/85 px-3 py-2 text-sm text-stone-800 outline-none placeholder:text-stone-400 focus:border-amber-700/25"
                />
              ) : null}
            </div>
          );
        })}
      </div>
    </aside>
  );
}
