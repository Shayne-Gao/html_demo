import type { ReactNode } from "react";
import { useEffect, useId, useRef, useState } from "react";
import type { PracticeMode, SkillRecord } from "@/types";
import SkillTooltip from "@/components/SkillTooltip";
import { getGradeTone } from "@/utils/taiwuData";

type SkillBadgeProps = {
  skill: SkillRecord;
  practiceMode?: PracticeMode;
  variant?: "chip" | "card";
  className?: string;
  subtitle?: string;
  interactiveTooltip?: boolean;
  tooltipFooter?: ReactNode;
};

export default function SkillBadge({
  skill,
  practiceMode = "正练",
  variant = "chip",
  className = "",
  subtitle,
  interactiveTooltip = false,
  tooltipFooter,
}: SkillBadgeProps) {
  const badgeId = useId();
  const [hovered, setHovered] = useState(false);
  const [tooltipPlacement, setTooltipPlacement] = useState<{
    vertical: "top" | "bottom";
    horizontal: "left" | "right";
    maxHeight: number;
  }>({ vertical: "bottom", horizontal: "left", maxHeight: 460 });
  const closeTimerRef = useRef<number | null>(null);
  const gradeTone = getGradeTone(skill.grade);

  const clearCloseTimer = () => {
    if (closeTimerRef.current !== null) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
  };

  useEffect(() => {
    const handleTooltipOpen = (event: Event) => {
      const nextBadgeId = (event as CustomEvent<string>).detail;
      if (nextBadgeId === badgeId) return;
      clearCloseTimer();
      setHovered(false);
    };

    window.addEventListener("taiwu-skill-tooltip-open", handleTooltipOpen);
    return () => window.removeEventListener("taiwu-skill-tooltip-open", handleTooltipOpen);
  }, [badgeId]);

  const handleMouseEnter = (event: React.MouseEvent<HTMLElement>) => {
    clearCloseTimer();
    window.dispatchEvent(new CustomEvent("taiwu-skill-tooltip-open", { detail: badgeId }));
    const rect = event.currentTarget.getBoundingClientRect();
    const tooltipWidth = 380;
    const spaceBelow = Math.max(180, window.innerHeight - rect.bottom - 20);
    const spaceAbove = Math.max(160, rect.top - 20);
    const preferBottom = spaceBelow >= 260 || spaceBelow >= spaceAbove;
    const vertical = preferBottom ? "bottom" : "top";
    const horizontal = rect.left + tooltipWidth <= window.innerWidth - 16 ? "left" : "right";
    const maxHeight = Math.min(460, vertical === "bottom" ? spaceBelow : spaceAbove);
    setTooltipPlacement({ vertical, horizontal, maxHeight });
    setHovered(true);
  };

  const handleMouseLeave = () => {
    clearCloseTimer();
    if (interactiveTooltip) {
      closeTimerRef.current = window.setTimeout(() => setHovered(false), 140);
      return;
    }
    setHovered(false);
  };

  const tooltipAnchorClass = [
    "absolute z-50",
    tooltipPlacement.vertical === "bottom" ? "top-full mt-1.5" : "bottom-full mb-1.5",
    tooltipPlacement.horizontal === "left" ? "left-0" : "right-0",
  ].join(" ");

  const handleTooltipEnter = () => {
    clearCloseTimer();
    setHovered(true);
  };

  const handleTooltipLeave = () => {
    clearCloseTimer();
    setHovered(false);
  };

  if (variant === "card") {
    return (
      <div
        className={`group relative isolate rounded-[22px] border bg-[linear-gradient(160deg,rgba(38,24,16,0.95),rgba(18,12,9,0.95))] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)] transition hover:z-20 hover:border-amber-300/30 hover:bg-[linear-gradient(160deg,rgba(58,38,24,0.95),rgba(25,16,12,0.95))] ${gradeTone.glow} ${className}`}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-serif text-base tracking-[0.08em] text-amber-50">{skill.name}</p>
            <p className="mt-1 text-xs tracking-[0.12em] text-stone-400">
              {[skill.faction, skill.grade, skill.route].filter(Boolean).join(" · ")}
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <span className={`rounded-full border px-2 py-1 text-[11px] ${gradeTone.badge}`}>
              {skill.grade || "未标阶"}
            </span>
            <span className="rounded-full border border-amber-300/20 px-2 py-1 text-[11px] text-amber-200">
              {practiceMode}
            </span>
          </div>
        </div>
        {subtitle ? <p className="mt-3 text-sm leading-6 text-stone-300/80">{subtitle}</p> : null}
        {hovered ? (
          <SkillTooltip
            skill={skill}
            practiceMode={practiceMode}
            style={{ maxHeight: `${tooltipPlacement.maxHeight}px` }}
            interactive={interactiveTooltip}
            footer={tooltipFooter}
            onMouseEnter={handleTooltipEnter}
            onMouseLeave={handleTooltipLeave}
            className={tooltipAnchorClass}
          />
        ) : null}
      </div>
    );
  }

  return (
    <div
      className={`relative isolate inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-left text-sm transition hover:z-20 hover:brightness-105 ${gradeTone.chip} ${gradeTone.glow} ${className}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <span className="font-medium text-current">{skill.name}</span>
      {skill.grade ? <span className="text-[11px] opacity-75">{skill.grade}</span> : null}
      {hovered ? (
        <SkillTooltip
          skill={skill}
          practiceMode={practiceMode}
          style={{ maxHeight: `${tooltipPlacement.maxHeight}px` }}
          interactive={interactiveTooltip}
          footer={tooltipFooter}
          onMouseEnter={handleTooltipEnter}
          onMouseLeave={handleTooltipLeave}
          className={tooltipAnchorClass}
        />
      ) : null}
    </div>
  );
}
