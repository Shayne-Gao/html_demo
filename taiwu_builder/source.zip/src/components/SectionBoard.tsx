import { useNavigate } from "react-router-dom";
import SkillBadge from "@/components/SkillBadge";
import type { BuildRecord, BuildSectionKey } from "@/types";
import { getSkillById } from "@/utils/taiwuData";

type SectionBoardProps = {
  build: BuildRecord;
  section: BuildSectionKey;
  onClear: (slotId: string) => void;
  onPractice: (slotId: string) => void;
};

export default function SectionBoard({ build, section, onClear, onPractice }: SectionBoardProps) {
  const navigate = useNavigate();
  const slots = build.sections[section];
  const filledCount = slots.filter((slot) => slot.skillId).length;

  return (
    <section className="rounded-[18px] border border-amber-800/10 bg-[#fbf5ec]/90 p-2 shadow-[0_8px_22px_rgba(114,78,39,0.05)]">
      <div className="grid gap-2 xl:grid-cols-[110px_minmax(0,1fr)]">
        <div className="w-[110px] shrink-0 rounded-[14px] border border-amber-800/10 bg-[linear-gradient(160deg,rgba(244,234,221,0.98),rgba(236,224,206,0.98))] px-3 py-2.5">
          <div className="flex items-center justify-between gap-2">
            <p className="font-serif text-base text-stone-800">{section}</p>
          </div>
          <div className="mt-2 inline-flex rounded-full border border-amber-800/12 bg-white/70 px-2 py-0.5 text-[11px] text-amber-900/80">
            {filledCount}/{slots.length}
          </div>
        </div>

        <div className="grid min-w-0 grid-cols-[repeat(auto-fit,minmax(164px,1fr))] gap-2">
          {slots.map((slot) => {
            const skill = getSkillById(slot.skillId);
            return (
              <div
                key={slot.slotId}
                className="relative min-w-0 rounded-[13px] border border-amber-900/10 bg-white/82 p-2 transition hover:z-10 hover:border-amber-700/18 hover:bg-white focus-within:z-10 focus-within:border-amber-700/18 focus-within:bg-white"
              >
                {skill ? (
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <SkillBadge
                          skill={skill}
                          practiceMode={slot.practiceMode}
                          interactiveTooltip
                          className="max-w-full align-top"
                          tooltipFooter={
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => onPractice(slot.slotId)}
                                className="flex-1 rounded-xl border border-cyan-300/35 bg-cyan-50 px-3 py-2 text-sm text-cyan-900 transition hover:bg-cyan-100"
                              >
                                切换为{slot.practiceMode === "正练" ? "逆练" : "正练"}
                              </button>
                              <button
                                type="button"
                                onClick={() => navigate(`/skills?buildId=${build.id}&section=${section}&slotId=${slot.slotId}`)}
                                className="flex-1 rounded-xl border border-amber-300/35 bg-amber-50 px-3 py-2 text-sm text-amber-900 transition hover:bg-amber-100"
                              >
                                替换功法
                              </button>
                              <button
                                type="button"
                                onClick={() => onClear(slot.slotId)}
                                className="rounded-xl border border-rose-300/35 bg-rose-50 px-3 py-2 text-sm text-rose-800 transition hover:bg-rose-100"
                              >
                                清空
                              </button>
                            </div>
                          }
                        />
                      </div>
                      <span className="shrink-0 rounded-full border border-amber-800/12 bg-amber-50 px-2 py-1 text-[11px] text-amber-900">
                        {slot.practiceMode}
                      </span>
                    </div>
                    <p className="line-clamp-1 text-[11px] leading-4 text-stone-600">
                      {[skill.faction, skill.route, skill.category].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => navigate(`/skills?buildId=${build.id}&section=${section}&slotId=${slot.slotId}`)}
                    className="flex min-h-10 w-full items-center justify-center rounded-[11px] border border-dashed border-amber-700/20 bg-[linear-gradient(160deg,rgba(255,255,255,0.76),rgba(245,235,222,0.88))] text-center text-xs text-amber-900 transition hover:border-amber-700/30 hover:bg-[linear-gradient(160deg,rgba(255,255,255,0.92),rgba(249,240,227,0.98))]"
                  >
                    + 加入功法
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
