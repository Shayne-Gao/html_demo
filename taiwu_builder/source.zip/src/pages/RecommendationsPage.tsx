import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import RecommendationGroupCard from "@/components/RecommendationGroupCard";
import { recommendationData } from "@/utils/taiwuData";

export default function RecommendationsPage() {
  const martialCategories = useMemo(
    () => Array.from(new Set(recommendationData.map((group) => group.martial_category))),
    [],
  );
  const [martialCategory, setMartialCategory] = useState(martialCategories[0] ?? "");
  const recommendationCategories = useMemo(
    () =>
      Array.from(
        new Set(
          recommendationData
            .filter((group) => group.martial_category === martialCategory)
            .map((group) => group.recommendation_category),
        ),
      ),
    [martialCategory],
  );
  const [recommendationCategory, setRecommendationCategory] = useState("");

  const visibleGroups = useMemo(() => {
    return recommendationData.filter((group) => {
      if (martialCategory && group.martial_category !== martialCategory) return false;
      if (recommendationCategory && group.recommendation_category !== recommendationCategory) return false;
      return true;
    });
  }, [martialCategory, recommendationCategory]);

  return (
    <div className="min-h-screen bg-[#050404] px-4 py-6 text-stone-100 md:px-6">
      <div className="mx-auto max-w-[1520px]">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs tracking-[0.22em] text-stone-500">前期推荐功法</p>
            <h1 className="mt-3 font-serif text-4xl text-amber-50">结构化推荐页</h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-stone-300/80">
              这里把 wiki 里的推荐组合拆成“武学分类 + 推荐分类 + 推荐理由”的结构。每一个功法标签都支持悬浮查看详情，方便你对照 Build 页面去挑选候选。
            </p>
          </div>
          <Link
            to="/"
            className="rounded-full border border-amber-300/20 bg-amber-100/10 px-4 py-3 text-sm text-amber-50 transition hover:border-amber-200/35 hover:bg-amber-100/15"
          >
            返回 Build 页面
          </Link>
        </div>

        <div className="sticky top-4 z-20 mb-6 space-y-4 rounded-[28px] border border-amber-200/10 bg-[#100b08]/92 p-4 backdrop-blur-xl">
          <div className="flex flex-wrap gap-2">
            {martialCategories.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => {
                  setMartialCategory(item);
                  setRecommendationCategory("");
                }}
                className={`rounded-full px-4 py-2 text-sm transition ${
                  martialCategory === item
                    ? "bg-amber-200 text-[#1a1008]"
                    : "border border-stone-700 bg-stone-900/80 text-stone-200 hover:border-amber-200/20"
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setRecommendationCategory("")}
              className={`rounded-full px-4 py-2 text-sm transition ${
                recommendationCategory === ""
                  ? "bg-cyan-200 text-[#081317]"
                  : "border border-stone-700 bg-stone-900/80 text-stone-200 hover:border-cyan-200/20"
              }`}
            >
              全部
            </button>
            {recommendationCategories.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setRecommendationCategory(item)}
                className={`rounded-full px-4 py-2 text-sm transition ${
                  recommendationCategory === item
                    ? "bg-cyan-200 text-[#081317]"
                    : "border border-stone-700 bg-stone-900/80 text-stone-200 hover:border-cyan-200/20"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 xl:grid-cols-2">
          {visibleGroups.map((group) => (
            <RecommendationGroupCard key={group.group_id} group={group} />
          ))}
        </div>
      </div>
    </div>
  );
}
