import { useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import SkillBadge from "@/components/SkillBadge";
import { useTaiwuStore } from "@/store/useTaiwuStore";
import type { BuildSectionKey, SkillFilterState } from "@/types";
import {
  buildSections,
  allCategories,
  allFactions,
  allGrades,
  allRoutes,
  getSkillSelectableSections,
  getSkillDisplayTags,
  skills as allSkills,
} from "@/utils/taiwuData";

const defaultFilters: SkillFilterState = {
  keyword: "",
  faction: "",
  category: "",
  grade: "",
  route: "",
};

const filterConfigs: Array<{
  key: keyof SkillFilterState;
  label: string;
  options: string[];
}> = [
  { key: "faction", label: "门派", options: allFactions },
  { key: "category", label: "分类", options: allCategories },
  { key: "grade", label: "品阶", options: allGrades },
  { key: "route", label: "路线", options: allRoutes },
];

export default function SkillsPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const targetBuildId = searchParams.get("buildId") || "";
  const sectionFromParams = searchParams.get("section") as BuildSectionKey | null;
  const defaultSection = targetBuildId && sectionFromParams ? sectionFromParams : "全部";
  const [currentSection, setCurrentSection] = useState<BuildSectionKey | "全部">(defaultSection);
  const slotId = searchParams.get("slotId") || "";
  const [filters, setFilters] = useState<SkillFilterState>(defaultFilters);
  const { builds, setBuildSkill } = useTaiwuStore();
  const build = builds.find((item) => item.id === targetBuildId);

  const skills = useMemo(() => {
    const base =
      currentSection === "全部"
        ? allSkills
        : allSkills.filter((skill) => getSkillSelectableSections(skill).includes(currentSection));

    const keyword = filters.keyword.trim().toLowerCase();
    return base.filter((skill) => {
      if (filters.faction && skill.faction !== filters.faction) return false;
      if (filters.category && skill.category !== filters.category) return false;
      if (filters.grade && skill.grade !== filters.grade) return false;
      if (filters.route && skill.route !== filters.route) return false;
      if (!keyword) return true;
      const haystack = [skill.name, skill.faction, skill.route, skill.category, skill.raw_text].join(" ").toLowerCase();
      return haystack.includes(keyword);
    });
  }, [currentSection, filters]);

  const selectSkill = (skillId: string) => {
    if (!build || !slotId || currentSection === "全部") return;
    setBuildSkill({ buildId: build.id, section: currentSection, slotId, skillId });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(126,70,18,0.22),rgba(5,4,4,1)_38%)] px-4 py-6 text-stone-100 md:px-6">
      <div className="mx-auto max-w-[1600px] rounded-[36px] border border-amber-200/10 bg-[#090707]/92 p-6 shadow-[0_30px_90px_rgba(0,0,0,0.5)]">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4 border-b border-amber-200/10 pb-5">
          <div>
            <p className="text-xs tracking-[0.22em] text-stone-500">功法选择页</p>
            <h1 className="mt-3 font-serif text-4xl text-amber-50">
              {currentSection === "全部" ? "功法大全" : `${currentSection} 候选功法`}
            </h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-stone-300/80">
              {build && slotId
                ? `当前目标：${build.name} / ${currentSection} / ${slotId}。点击功法会直接写回 Build 页面。`
                : "这里展示全部已收录功法；可先按分区切换，再按门派、品阶和路线筛选。"}
            </p>
          </div>
          <Link
            to="/"
            className="rounded-full border border-amber-300/20 bg-amber-100/10 px-4 py-3 text-sm text-amber-50 transition hover:border-amber-200/35 hover:bg-amber-100/15"
          >
            返回 Build 页面
          </Link>
        </div>

        <div className="mb-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setCurrentSection("全部")}
            className={`rounded-full border px-4 py-2 text-sm transition ${
              currentSection === "全部"
                ? "border-amber-300/30 bg-amber-100/12 text-amber-50"
                : "border-stone-700 bg-stone-950/70 text-stone-300 hover:border-amber-200/20 hover:text-amber-100"
            }`}
          >
            全部
          </button>
          {buildSections.map((section) => (
            <button
              key={section}
              type="button"
              onClick={() => setCurrentSection(section)}
              className={`rounded-full border px-4 py-2 text-sm transition ${
                currentSection === section
                  ? "border-amber-300/30 bg-amber-100/12 text-amber-50"
                  : "border-stone-700 bg-stone-950/70 text-stone-300 hover:border-amber-200/20 hover:text-amber-100"
              }`}
            >
              {section}
            </button>
          ))}
        </div>

        <div className="mb-6 grid gap-3 rounded-[28px] border border-amber-200/10 bg-[#100b08]/86 p-4 md:grid-cols-2 xl:grid-cols-5">
          <input
            value={filters.keyword}
            onChange={(event) => setFilters((prev) => ({ ...prev, keyword: event.target.value }))}
            placeholder="搜索功法名 / 门派 / 效果"
            className="rounded-2xl border border-stone-700 bg-stone-950/75 px-4 py-3 text-sm text-stone-100 outline-none placeholder:text-stone-500 focus:border-amber-300/35"
          />
          {filterConfigs.map(({ key, label, options }) => (
              <select
                key={key}
                value={filters[key]}
                onChange={(event) =>
                  setFilters((prev) => ({ ...prev, [key]: event.target.value } as SkillFilterState))
                }
                className="rounded-2xl border border-stone-700 bg-stone-950/75 px-4 py-3 text-sm text-stone-100 outline-none focus:border-amber-300/35"
              >
                <option value="">全部{label}</option>
                {options.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            ))}
        </div>

        <div className="mb-4 text-sm text-stone-400">共筛到 {skills.length} 个可选功法</div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {skills.map((skill) => (
            <button
              key={skill.id}
              type="button"
              onClick={() => selectSkill(skill.id)}
              disabled={!build || !slotId || currentSection === "全部"}
              className="rounded-[26px] border border-amber-200/10 bg-[linear-gradient(145deg,rgba(24,16,12,0.94),rgba(10,9,8,0.98))] p-4 text-left shadow-[0_18px_45px_rgba(0,0,0,0.3)] transition hover:border-amber-200/28 hover:-translate-y-0.5"
            >
              <SkillBadge skill={skill} variant="card" className="border-0 bg-transparent p-0 shadow-none" />
              <div className="mt-4 flex flex-wrap gap-2">
                {getSkillDisplayTags(skill).map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-stone-700 bg-stone-900/90 px-2 py-1 text-[11px] text-stone-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <p className="mt-4 line-clamp-3 text-sm leading-7 text-stone-300/75">
                {skill.paragraphs[0] || skill.raw_text}
              </p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
