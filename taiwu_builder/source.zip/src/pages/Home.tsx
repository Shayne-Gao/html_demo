import { NavLink } from "react-router-dom";
import BuildSidebar from "@/components/BuildSidebar";
import SectionBoard from "@/components/SectionBoard";
import { useTaiwuStore } from "@/store/useTaiwuStore";
import { buildSections } from "@/utils/taiwuData";

export default function Home() {
  const { builds, selectedBuildId, selectBuild, createBuild, renameBuild, clearBuildSkill, setPracticeMode } =
    useTaiwuStore();
  const currentBuild = builds.find((build) => build.id === selectedBuildId) ?? builds[0];
  const filledCount = Object.values(currentBuild.sections)
    .flat()
    .filter((slot) => slot.skillId).length;
  const totalCount = Object.values(currentBuild.sections).flat().length;

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(205,163,110,0.18),rgba(247,240,230,0.98)_42%,rgba(238,228,214,1)_100%)] px-3 py-3 text-stone-800 md:px-4">
      <div className="mx-auto mb-3 max-w-[1880px] rounded-[18px] border border-amber-900/10 bg-[#fbf5eb]/92 p-2 shadow-[0_12px_32px_rgba(114,78,39,0.08)]">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { to: "/", label: "Build 模拟" },
            { to: "/skills", label: "功法大全" },
            { to: "/recommendations", label: "前期推荐" },
          ].map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                `rounded-full border px-4 py-2 text-sm transition ${
                  isActive
                    ? "border-amber-800/20 bg-amber-100/45 text-amber-950"
                    : "border-amber-900/10 bg-white/72 text-stone-700 hover:border-amber-800/15 hover:bg-white hover:text-amber-900"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>
      </div>

      <div className="mx-auto grid min-h-[calc(100vh-5.2rem)] max-w-[1880px] gap-3 xl:grid-cols-[220px_minmax(0,1fr)]">
        <BuildSidebar
          builds={builds}
          selectedBuildId={currentBuild.id}
          onSelect={selectBuild}
          onCreate={createBuild}
          onRename={renameBuild}
        />

        <main className="overflow-hidden rounded-[24px] border border-amber-900/10 bg-[radial-gradient(circle_at_top,rgba(212,178,135,0.18),rgba(250,244,235,0.98)_40%,rgba(245,236,224,0.98)_100%)] p-3 shadow-[0_20px_60px_rgba(114,78,39,0.08)]">
          <header className="mb-3 rounded-[18px] border border-amber-900/8 bg-white/45 px-4 py-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="font-serif text-[30px] leading-none text-stone-900">{currentBuild.name}</h1>
                  <span className="rounded-full border border-amber-900/10 bg-white/70 px-3 py-1 text-[11px] tracking-[0.08em] text-stone-700">
                    {filledCount}/{totalCount} 已配置
                  </span>
                  <span className="rounded-full border border-amber-800/15 bg-amber-100/55 px-3 py-1 text-[11px] tracking-[0.08em] text-amber-950">
                    {currentBuild.theme}
                  </span>
                </div>
              </div>
            </div>
          </header>

          <div className="mb-3 grid gap-2 xl:grid-cols-5">
            {buildSections.map((section) => (
              <div key={section} className="rounded-[14px] border border-amber-900/8 bg-[linear-gradient(160deg,rgba(251,244,235,0.98),rgba(242,232,216,0.98))] px-3 py-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-serif text-[15px] text-stone-900">{section}</span>
                  <span className="text-[11px] text-stone-500">
                    {
                      currentBuild.sections[section].filter((slot) => slot.skillId).length
                    }
                    /{currentBuild.sections[section].length}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            {buildSections.map((section) => (
              <SectionBoard
                key={section}
                build={currentBuild}
                section={section}
                onClear={(slotId) => clearBuildSkill({ buildId: currentBuild.id, section, slotId })}
                onPractice={(slotId) => {
                  const slot = currentBuild.sections[section].find((item) => item.slotId === slotId);
                  if (!slot) return;
                  setPracticeMode({
                    buildId: currentBuild.id,
                    section,
                    slotId,
                    mode: slot.practiceMode === "正练" ? "逆练" : "正练",
                  });
                }}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
