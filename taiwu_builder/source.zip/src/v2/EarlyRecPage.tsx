import { useMemo } from "react";
import type { BuildSectionKey, RecommendationGroup } from "@/types";
import { buildSections, getSkillById, recommendationData } from "@/utils/taiwuData";
import SkillChip from "./SkillChip";
import { useSkillHover } from "./useSkillHover";

const SECTION_ICONS: Record<BuildSectionKey, string> = {
  内功: "内",
  摧破: "摧",
  轻灵: "轻",
  护体: "护",
  奇窍: "奇",
};

type Row = {
  section: BuildSectionKey;
  sectionRowSpan: number;
  isSectionFirst: boolean;
  subCategory: string;
  subRowSpan: number;
  isSubFirst: boolean;
  group: RecommendationGroup;
};

/**
 * 前期功法推荐：紧凑大表
 * 列：分类(sectionRowSpan 合并) / 子类(subRowSpan 合并) / 推荐功法 / 推荐理由
 */
export default function EarlyRecPage() {
  const { onEnter, onLeave, hoverNode } = useSkillHover();

  const rows: Row[] = useMemo(() => {
    // 先按 section -> subCategory 聚合
    const sectionMap = new Map<BuildSectionKey, Map<string, RecommendationGroup[]>>();
    for (const g of recommendationData) {
      const sec = g.martial_category as BuildSectionKey;
      if (!buildSections.includes(sec)) continue;
      if (!sectionMap.has(sec)) sectionMap.set(sec, new Map());
      const sub = sectionMap.get(sec)!;
      if (!sub.has(g.recommendation_category)) sub.set(g.recommendation_category, []);
      sub.get(g.recommendation_category)!.push(g);
    }

    const out: Row[] = [];
    for (const sec of buildSections) {
      const sub = sectionMap.get(sec);
      if (!sub) continue;
      const sectionTotal = Array.from(sub.values()).reduce((acc, arr) => acc + arr.length, 0);
      let sectionFirstUsed = false;
      for (const [subName, groups] of sub.entries()) {
        let subFirstUsed = false;
        for (const g of groups) {
          out.push({
            section: sec,
            sectionRowSpan: sectionTotal,
            isSectionFirst: !sectionFirstUsed,
            subCategory: subName,
            subRowSpan: groups.length,
            isSubFirst: !subFirstUsed,
            group: g,
          });
          sectionFirstUsed = true;
          subFirstUsed = true;
        }
      }
    }
    return out;
  }, []);

  return (
    <div className="min-h-[calc(100vh-100px)] bg-[#0b0b0c] text-[#f4ecd8]">
      <main className="px-5 pb-10 pt-4">
        <div className="flex items-baseline justify-between">
          <h1 className="font-serif text-3xl tracking-wider text-[#f4ecd8]">前期功法推荐</h1>
          <p className="text-[13px] text-[#9a927d]">
            数据源：太吾绘卷 wiki · hover 卡片可查看正逆练对比
          </p>
        </div>

        <div className="mt-3 overflow-hidden rounded-lg border border-[#caa75a]/25 bg-[#15140f] shadow-[0_8px_28px_rgba(0,0,0,0.6)]">
          <table className="w-full border-collapse text-[14px]">
            <thead>
              <tr className="bg-[#1c1a14] text-left text-[13px] text-[#caa75a]">
                <th className="w-[72px] border-b border-[#caa75a]/20 px-2 py-2 text-center font-serif">分类</th>
                <th className="w-[110px] border-b border-[#caa75a]/20 px-2 py-2 font-serif">子类</th>
                <th className="border-b border-[#caa75a]/20 px-2 py-2 font-serif">推荐功法</th>
                <th className="border-b border-[#caa75a]/20 px-2 py-2 font-serif">推荐理由</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, idx) => {
                const next = rows[idx + 1];
                const isSectionLast = !next || next.section !== r.section;
                const isSubLast = !next || next.section !== r.section || next.subCategory !== r.subCategory;
                return (
                  <tr key={r.group.group_id} className="align-top">
                    {r.isSectionFirst ? (
                      <td
                        rowSpan={r.sectionRowSpan}
                        className="border-r border-[#caa75a]/15 bg-[#1c1a14]/60 px-2 py-2 text-center"
                      >
                        <div className="flex flex-col items-center gap-1">
                          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#caa75a] font-serif text-[15px] text-[#1a1812]">
                            {SECTION_ICONS[r.section]}
                          </span>
                          <span className="font-serif text-[15px] tracking-wider">{r.section}</span>
                        </div>
                      </td>
                    ) : null}
                    {r.isSubFirst ? (
                      <td
                        rowSpan={r.subRowSpan}
                        className={`border-r border-[#caa75a]/15 px-2 py-2 font-serif text-[14px] text-[#caa75a] ${
                          isSectionLast ? "" : ""
                        }`}
                      >
                        {r.subCategory}
                      </td>
                    ) : null}
                    <td
                      className={`px-2 py-1.5 ${
                        isSubLast ? "border-b border-[#caa75a]/15" : "border-b border-[#caa75a]/8"
                      }`}
                    >
                      <div className="flex flex-wrap items-center gap-1.5">
                        {r.group.skill_ids.map((id, i) => {
                          const skill = getSkillById(id);
                          if (!skill) return null;
                          const wikiName = r.group.skill_names?.[i] || "";
                          const m = /^([正逆])·/.exec(wikiName);
                          return (
                            <SkillChip
                              key={`${r.group.group_id}-${id}`}
                              skill={skill}
                              onEnter={onEnter}
                              onLeave={onLeave}
                              prefix={m ? `${m[1]}·` : undefined}
                            />
                          );
                        })}
                      </div>
                    </td>
                    <td
                      className={`px-2 py-1.5 text-[13px] leading-relaxed text-[#c9c2af] ${
                        isSubLast ? "border-b border-[#caa75a]/15" : "border-b border-[#caa75a]/8"
                      } ${isSectionLast && isSubLast ? "" : ""}`}
                    >
                      {r.group.recommendation_reason || ""}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </main>
      {hoverNode}
    </div>
  );
}
