import { useMemo } from "react";
import type { BuildSectionKey, RecommendationGroup } from "@/types";
import { buildSections, getSkillById, recommendationData } from "@/utils/taiwuData";
import SkillChip from "./SkillChip";
import { useSkillHover } from "./useSkillHover";

const SECTION_ICONS: Record<BuildSectionKey, string> = {
  内功: "内",
  摧破: "摧",
  轻灵: "轻",
  护体: "护",
  奇窍: "奇",
};

/**
 * 前期功法推荐页面：
 * - 按 martial_category（内功/摧破/...）大段、recommendation_category（通用/直伤/...）小组
 * - 每组列出 chips + 推荐理由
 * - hover 复用统一的 SkillHoverCard（含正逆练 diff）
 */
export default function EarlyRecPage() {
  const { onEnter, onLeave, hoverNode } = useSkillHover();

  const sections = useMemo(() => {
    const bySection = new Map<string, Map<string, RecommendationGroup[]>>();
    for (const g of recommendationData) {
      if (!bySection.has(g.martial_category)) bySection.set(g.martial_category, new Map());
      const sub = bySection.get(g.martial_category)!;
      if (!sub.has(g.recommendation_category)) sub.set(g.recommendation_category, []);
      sub.get(g.recommendation_category)!.push(g);
    }
    return buildSections
      .filter((sec) => bySection.has(sec))
      .map((sec) => ({
        section: sec as BuildSectionKey,
        subs: Array.from(bySection.get(sec)!.entries()).map(([name, groups]) => ({
          name,
          groups,
        })),
      }));
  }, []);

  return (
    <div className="min-h-[calc(100vh-100px)] bg-[#0b0b0c] text-[#f4ecd8]">
      <main className="px-5 pb-10 pt-4">
        <div className="flex items-baseline justify-between">
          <h1 className="font-serif text-3xl tracking-wider text-[#f4ecd8]">前期功法推荐</h1>
          <p className="text-[13px] text-[#9a927d]">
            数据源：太吾绘卷 wiki · hover 卡片可查看正逆练对比
          </p>
        </div>

        <div className="mt-4 space-y-4">
          {sections.map(({ section, subs }) => (
            <section
              key={section}
              className="overflow-hidden rounded-2xl border border-[#caa75a]/25 bg-[#15140f] shadow-[0_8px_28px_rgba(0,0,0,0.6)]"
            >
              {/* 分类大标题 */}
              <div className="flex items-center gap-3 border-b border-[#caa75a]/15 bg-[#1c1a14] px-4 py-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#caa75a] font-serif text-[15px] text-[#1a1812]">
                  {SECTION_ICONS[section]}
                </span>
                <span className="font-serif text-[18px] tracking-wider">{section}</span>
                <span className="text-[12px] text-[#9a927d]">
                  · {subs.reduce((acc, s) => acc + s.groups.length, 0)} 组推荐
                </span>
              </div>

              {/* 子类目分组 */}
              <div className="divide-y divide-[#caa75a]/10">
                {subs.map(({ name, groups }) => (
                  <div key={name} className="px-4 py-3">
                    <p className="font-serif text-[15px] text-[#caa75a]">{name}</p>
                    <div className="mt-2 space-y-2.5">
                      {groups.map((g) => (
                        <RecRow key={g.group_id} group={g} onEnter={onEnter} onLeave={onLeave} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>
      {hoverNode}
    </div>
  );
}

function RecRow({
  group,
  onEnter,
  onLeave,
}: {
  group: RecommendationGroup;
  onEnter: (skillId: string, anchor: HTMLElement) => void;
  onLeave: () => void;
}) {
  return (
    <div className="flex flex-col gap-1.5 rounded-md bg-[#0b0b0c]/40 px-2.5 py-2">
      <div className="flex flex-wrap items-center gap-1.5">
        {group.skill_ids.map((id, i) => {
          const skill = getSkillById(id);
          if (!skill) return null;
          // 推荐名字里如 "逆·罗汉功" 的前缀，剥出来给 chip 显示
          const wikiName = group.skill_names?.[i] || "";
          const prefixMatch = /^([正逆])·/.exec(wikiName);
          return (
            <SkillChip
              key={`${group.group_id}-${id}`}
              skill={skill}
              onEnter={onEnter}
              onLeave={onLeave}
              prefix={prefixMatch ? `${prefixMatch[1]}·` : undefined}
            />
          );
        })}
      </div>
      {group.recommendation_reason ? (
        <p className="text-[13px] leading-relaxed text-[#c9c2af]">
          {group.recommendation_reason}
        </p>
      ) : null}
    </div>
  );
}
