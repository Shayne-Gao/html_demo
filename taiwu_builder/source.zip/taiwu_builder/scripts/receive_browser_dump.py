#!/usr/bin/env python3
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent.parent / "data" / "raw" / "browser_dump"
ROOT.mkdir(parents=True, exist_ok=True)


class Handler(BaseHTTPRequestHandler):
    def _send(self, code=200, payload=None):
        body = json.dumps(payload or {"ok": True}, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(204, {})

    def do_GET(self):
        if self.path.startswith("/health"):
            self._send(200, {"ok": True, "root": str(ROOT)})
            return
        self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/save":
            self._send(404, {"ok": False, "error": "not found"})
            return
        qs = parse_qs(parsed.query)
        name = (qs.get("name") or ["payload.json"])[0]
        safe_name = Path(name).name
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        out = ROOT / safe_name
        out.write_bytes(raw)
        self._send(200, {"ok": True, "saved": str(out), "bytes": len(raw)})


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", 8765), Handler)
    print(f"listening on http://127.0.0.1:8765 -> {ROOT}")
    server.serve_forever()
