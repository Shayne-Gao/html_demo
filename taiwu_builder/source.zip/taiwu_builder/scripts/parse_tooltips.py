#!/usr/bin/env python3
import glob
import html
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw" / "browser_dump"
PARSED_DIR = ROOT / "data" / "parsed"
PARSED_DIR.mkdir(parents=True, exist_ok=True)


TAG_RE = re.compile(r"<[^>]+>")
TITLE_RE = re.compile(r'<div class="tt-title">(.*?)</div>', re.S)
META_RE = re.compile(r'<p style="text-align:center">(.*?)</p>', re.S)
P_RE = re.compile(r"<p\b[^>]*>(.*?)</p>", re.S)
UL_RE = re.compile(r"<ul>(.*?)</ul>", re.S)
LI_RE = re.compile(r"<li>(.*?)</li>", re.S)
PRACTICE_RE = re.compile(
    r"<b[^>]*>([^<]*(?:正练|逆练))</b>\s*</p>\s*<p>(.*?)</p>",
    re.S,
)


def clean_html_text(value: str) -> str:
    value = value.replace("<br />", "\n").replace("<br/>", "\n").replace("<br>", "\n")
    value = TAG_RE.sub("", value)
    value = html.unescape(value)
    value = value.replace("\xa0", " ")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n\s*\n+", "\n", value)
    return value.strip()


def parse_meta(meta_html: str):
    raw = TAG_RE.sub("", meta_html)
    raw = html.unescape(raw)
    raw = raw.replace("\n", " ").replace("\t", " ")
    raw = re.sub(r"[ \xa0]{2,}", "||", raw)
    raw = re.sub(r"[ \xa0]+", " ", raw).strip()
    parts = [p.strip() for p in raw.split("||") if p.strip()]
    faction = parts[0] if len(parts) > 0 else None
    grade = parts[1] if len(parts) > 1 else None
    route = parts[2] if len(parts) > 2 else None
    category = parts[3] if len(parts) > 3 else None
    shape = parts[4] if len(parts) > 4 else None
    return {
        "raw": raw.replace("||", "  "),
        "faction": faction,
        "grade": grade,
        "route": route,
        "category": category,
        "shape": shape,
    }


def parse_sections(raw_html: str):
    paragraphs = [clean_html_text(x) for x in P_RE.findall(raw_html)]
    paragraphs = [x for x in paragraphs if x]
    bullet_lists = []
    for ul in UL_RE.findall(raw_html):
        items = [clean_html_text(x) for x in LI_RE.findall(ul)]
        items = [x for x in items if x]
        if items:
            bullet_lists.append(items)
    practice = []
    for title, body in PRACTICE_RE.findall(raw_html):
        practice.append(
            {
                "title": clean_html_text(title),
                "effect": clean_html_text(body),
            }
        )
    return {
        "paragraphs": paragraphs,
        "bullet_lists": bullet_lists,
        "practice_effects": practice,
    }


def parse_item(item: dict):
    raw_html = item["html"]
    title_match = TITLE_RE.search(raw_html)
    meta_match = META_RE.search(raw_html)
    title = clean_html_text(title_match.group(1)) if title_match else item["name"]
    meta = parse_meta(meta_match.group(1)) if meta_match else {}
    sections = parse_sections(raw_html)
    return {
        "id": str(item["id"]),
        "name": title,
        "href": item.get("href"),
        "faction": meta.get("faction"),
        "grade": meta.get("grade"),
        "route": meta.get("route"),
        "category": meta.get("category"),
        "shape": meta.get("shape"),
        "meta_text": meta.get("raw"),
        "practice_effects": sections["practice_effects"],
        "paragraphs": sections["paragraphs"],
        "bullet_lists": sections["bullet_lists"],
        "raw_text": item.get("text"),
        "raw_html": raw_html,
    }


def main():
    manifest = json.loads((RAW_DIR / "skills_manifest.json").read_text())
    chunk_paths = sorted(glob.glob(str(RAW_DIR / "tooltip_chunk_*.json")))
    items = []
    seen = set()
    for path in chunk_paths:
        payload = json.loads(Path(path).read_text())
        for item in payload["items"]:
            if item["id"] in seen:
                continue
            seen.add(item["id"])
            items.append(item)

    parsed_items = [parse_item(x) for x in items]
    parsed_items.sort(key=lambda x: int(x["id"]))

    combined_raw = {
        "source": {
            "page": "https://taiwu.huijiwiki.com/wiki/功法一览?filter-gongfa=v1:空桑派",
            "capture_method": "integrated_browser + tooltip api in current opened browser session",
            "count": len(items),
        },
        "manifest": {
            "total": manifest["total"],
            "visible_count": manifest["visible_count"],
            "visible_ids": manifest["visible_ids"],
        },
        "items": items,
    }
    combined_parsed = {
        "source": combined_raw["source"],
        "manifest": combined_raw["manifest"],
        "items": parsed_items,
    }

    (PARSED_DIR / "skills_tooltips_raw.json").write_text(
        json.dumps(combined_raw, ensure_ascii=False, indent=2)
    )
    (PARSED_DIR / "skills.json").write_text(
        json.dumps(combined_parsed, ensure_ascii=False, indent=2)
    )
    print(f"raw_items={len(items)} parsed_items={len(parsed_items)}")
    print(PARSED_DIR / "skills_tooltips_raw.json")
    print(PARSED_DIR / "skills.json")


if __name__ == "__main__":
    main()
