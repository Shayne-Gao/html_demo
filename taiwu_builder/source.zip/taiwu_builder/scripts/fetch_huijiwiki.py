#!/usr/bin/env python3
"""从 TRAE 内置浏览器 (trae-webview profile) 的 SQLite cookies 复用 huijiwiki 的会话，
直接调 MediaWiki API 拿原始 wikitext + 渲染 HTML。"""
import json
import os
import sqlite3
import sys
import urllib.parse
import urllib.request
from pathlib import Path

PROFILE_DB = Path.home() / "Library/Application Support/Trae/Partitions/trae-webview/Cookies"
RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)

# TRAE webview 大概率走 Electron 内嵌 Chromium，这里给一个常见 macOS Chrome UA。
# 如果 CF 校验 UA 严格，需要换成 webview 实际 UA（document.userAgent）。
DEFAULT_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
)


def load_cookies():
    if not PROFILE_DB.exists():
        sys.exit(f"cookies db not found: {PROFILE_DB}")
    tmp = "/tmp/_trae_webview_cookies_copy.db"
    # 直接读取可能被锁，先复制
    import shutil
    shutil.copy(PROFILE_DB, tmp)
    con = sqlite3.connect(tmp)
    rows = con.execute(
        "SELECT host_key, name, value FROM cookies "
        "WHERE host_key LIKE '%huijiwiki%'"
    ).fetchall()
    con.close()
    return rows


def build_cookie_header(rows):
    parts = []
    for _, name, value in rows:
        parts.append(f"{name}={value}")
    return "; ".join(parts)


def fetch(url, cookie_header, ua=DEFAULT_UA):
    # 用 curl_cffi 模拟 Chrome 的 TLS/HTTP2 指纹，否则 huijiwiki 的 Cloudflare
    # 即便带上正确的 cf_clearance + UA 仍会判定为 managed challenge。
    from curl_cffi import requests as cffi_requests
    headers = {
        "User-Agent": ua,
        "Accept": "application/json, text/html;q=0.9, */*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Referer": "https://taiwu.huijiwiki.com/wiki/%E5%8A%9F%E6%B3%95%E4%B8%80%E8%A7%88",
        "Cookie": cookie_header,
        "sec-ch-ua": '"Not=A?Brand";v="99", "Chromium";v="142"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"macOS"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
    }
    r = cffi_requests.get(url, headers=headers, impersonate="chrome", timeout=30)
    return r.status_code, dict(r.headers), r.content


def main():
    page = sys.argv[1] if len(sys.argv) > 1 else "功法一览"
    out_stem = sys.argv[2] if len(sys.argv) > 2 else "gongfa_yilan"
    rows = load_cookies()
    if not rows:
        sys.exit("no huijiwiki cookies found in trae-webview profile")
    print(f"loaded {len(rows)} cookies for huijiwiki")
    cookie_header = build_cookie_header(rows)

    page_enc = urllib.parse.quote(page, safe="")
    api = (
        f"https://taiwu.huijiwiki.com/w/api.php?action=parse&page={page_enc}"
        f"&prop=wikitext|text&format=json&formatversion=2"
    )
    print("GET", api)
    status, hdrs, body = fetch(api, cookie_header)
    print("HTTP", status, "bytes", len(body))
    print("server:", hdrs.get("Server"), "cf-ray:", hdrs.get("CF-RAY"), "cf-mitigated:", hdrs.get("Cf-Mitigated"))
    out = RAW_DIR / f"{out_stem}.json"
    out.write_bytes(body)
    print("saved", out)
    if body[:200].lstrip().startswith(b"<") or b"Just a moment" in body[:2048]:
        print("---- response head ----")
        print(body[:600].decode("utf-8", "replace"))
        sys.exit("looks like a Cloudflare challenge page, cookie/UA may not match")
    try:
        data = json.loads(body)
        wt_len = len(data.get("parse", {}).get("wikitext", ""))
        html_len = len(data.get("parse", {}).get("text", ""))
        print(f"wikitext_chars={wt_len} html_chars={html_len}")
    except Exception as e:
        print("warn: not JSON:", e)


if __name__ == "__main__":
    main()
