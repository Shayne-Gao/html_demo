import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

type Pos = { x: number; y: number };

type Props = {
  anchor: HTMLElement | null;
  open: boolean;
  width?: number;
  preferred?: "below" | "above" | "auto";
  children: React.ReactNode;
  onPointerEnter?: () => void;
  onPointerLeave?: () => void;
};

/**
 * 把内容 portal 到 body，按 anchor 的 boundingClientRect 计算位置。
 * - 优先放在 anchor 下方；不够则放上方
 * - 横向贴 anchor 左边，超出右侧时改为贴 anchor 右边
 * - 高度自适应，超过可用空间内部滚动
 */
export default function FloatingLayer({
  anchor,
  open,
  width = 320,
  preferred = "auto",
  children,
  onPointerEnter,
  onPointerLeave,
}: Props) {
  const [pos, setPos] = useState<Pos | null>(null);
  const [maxH, setMaxH] = useState<number>(320);
  const [placement, setPlacement] = useState<"below" | "above">("below");

  useEffect(() => {
    if (!open || !anchor) {
      setPos(null);
      return;
    }
    const compute = () => {
      const r = anchor.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const margin = 12;
      const gap = 6;

      const spaceBelow = vh - r.bottom - margin;
      const spaceAbove = r.top - margin;
      const wantBelow = preferred === "above" ? false : preferred === "below" ? true : spaceBelow >= 180 || spaceBelow >= spaceAbove;
      const finalPlace: "below" | "above" = wantBelow ? "below" : "above";
      const avail = finalPlace === "below" ? spaceBelow - gap : spaceAbove - gap;

      let x = r.left;
      if (x + width > vw - margin) x = vw - margin - width;
      if (x < margin) x = margin;

      const y = finalPlace === "below" ? r.bottom + gap : r.top - gap; // y 是浮层一端

      setPlacement(finalPlace);
      setPos({ x, y });
      setMaxH(Math.max(160, Math.min(480, avail)));
    };
    compute();
    window.addEventListener("scroll", compute, true);
    window.addEventListener("resize", compute);
    return () => {
      window.removeEventListener("scroll", compute, true);
      window.removeEventListener("resize", compute);
    };
  }, [open, anchor, width, preferred]);

  if (!open || !pos) return null;

  const style: React.CSSProperties =
    placement === "below"
      ? { position: "fixed", left: pos.x, top: pos.y, width, maxHeight: maxH }
      : { position: "fixed", left: pos.x, bottom: window.innerHeight - pos.y, width, maxHeight: maxH };

  return createPortal(
    <div
      style={{ ...style, zIndex: 200 }}
      onPointerEnter={onPointerEnter}
      onPointerLeave={onPointerLeave}
    >
      {children}
    </div>,
    document.body,
  );
}
