import { HashRouter as Router, Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import RecommendationsPage from "@/pages/RecommendationsPage";
import SkillsPage from "@/pages/SkillsPage";
import BuilderPageV2 from "@/v2/BuilderPageV2";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recommendations" element={<RecommendationsPage />} />
        <Route path="/skills" element={<SkillsPage />} />
        <Route path="/v2" element={<BuilderPageV2 />} />
      </Routes>
    </Router>
  );
}
